from django.shortcuts import redirect,render
from User.form import CustomUserForm
from . models import *
from django.contrib import messages

def home(request):    
    return render(request,"users/index.html")

def register(request):
    form =CustomUserForm
    return render(request,"users/register.html",{'form ': form})

def collections(request):
    Catagory=catagory.objects.filter(status=0)
    context={"Catagory":Catagory}
    return render(request,"users/collections.html",context)

# def collectionsview(request,name):
#     if (catagory.objects.filter(name=name,status=0)):
#        products=product.objects.filter(Catagory__name=name)       
#        return render(request,"users/products/index.html",{"products":products})
#     else:
#         messages.warning(request,"NO Such Catagory Found")
        
        

def about(request):
    return render(request,"users/about.html")
def contact(request):
    return render(request,"users/contact.html")

                                                                                                