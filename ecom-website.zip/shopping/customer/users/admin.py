from django.contrib import admin
from .models import *

# class categoryAdmin(admin.ModelAdmin):  #to show the imformation in django's administration
#     list_display=('name','image','description')


admin.site.register(catagory) #if we want to show information pass the classname as a second parameter
admin.site.register(product)
